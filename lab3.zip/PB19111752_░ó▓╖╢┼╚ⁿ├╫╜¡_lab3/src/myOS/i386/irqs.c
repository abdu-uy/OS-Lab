extern void put_chars(char* str, int color, int row, int col);
void ignoreIntBody(void){
    put_chars("Unknown interrupt1\0",0x4,24,0);
}


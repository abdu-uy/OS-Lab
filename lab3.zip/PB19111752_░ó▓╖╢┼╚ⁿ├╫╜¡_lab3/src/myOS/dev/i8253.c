extern unsigned char inb(unsigned short int port_from);
extern void outb (unsigned short int port_to, unsigned char value);
extern void io_wait(void);
extern int myPrintk(int color, const char* format, ...);


//初始化 8253

void init8253(void){
    unsigned short fq = 11932;//set frequency 
    unsigned char high,low;

    high = fq>>8;
    low = fq;
    outb(0x43,0x34);//  control byte
    io_wait();
    outb(0x40,low);// high 8 bits
    io_wait();
    outb(0x40,high);// low 8 bits
    io_wait();
}


